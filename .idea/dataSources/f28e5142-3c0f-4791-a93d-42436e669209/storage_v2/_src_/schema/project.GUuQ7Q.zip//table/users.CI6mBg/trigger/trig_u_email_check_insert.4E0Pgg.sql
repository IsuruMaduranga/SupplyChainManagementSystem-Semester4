create trigger trig_u_email_check_insert
  before INSERT
  on users
  for each row
  BEGIN
				IF NEW.email NOT LIKE "%@%.%" THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid Email';
				END IF;
			END;

