create trigger trig_salary_check_update
  before UPDATE
  on employees
  for each row
  BEGIN
				IF NEW.salary <0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid Salary Amount';
				END IF;
			END;

