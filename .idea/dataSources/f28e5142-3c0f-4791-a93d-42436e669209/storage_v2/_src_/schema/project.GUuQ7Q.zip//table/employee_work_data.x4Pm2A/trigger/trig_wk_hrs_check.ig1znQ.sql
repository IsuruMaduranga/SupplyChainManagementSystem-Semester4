create trigger trig_wk_hrs_check
  before INSERT
  on employee_work_data
  for each row
  BEGIN
			IF HOUR(NEW.workhours)>0 AND HOUR(NEW.workhours)<40
				THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid Email';
			END IF;
		END;

